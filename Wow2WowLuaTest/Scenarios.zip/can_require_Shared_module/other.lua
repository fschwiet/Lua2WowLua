module('other', package.seeall);
require('shared');
function set(value)
    shared.set(value);
end
