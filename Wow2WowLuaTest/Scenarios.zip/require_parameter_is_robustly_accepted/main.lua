require('printA')  -- without extension
require("subpath/printB")  -- in a sub-path
require "printC" -- without parenthesis

