require("include.lua")
print("expecting a to be 2, it is: " .. a);
print("expecting b to be nil, it is: " .. tostring(b));
