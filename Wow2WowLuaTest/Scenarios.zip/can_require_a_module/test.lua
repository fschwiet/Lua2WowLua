local _LOADED_zz_include_env = {};
for key,value in pairs(getfenv()) do
    _LOADED_zz_include_env[key] = value;
end

local _LOADER_zz_include = function()
    _LOADER_zz_include = function() end;
    (function() 
        function a()
            return 2;
        end
       end)();
end;
setfenv(_LOADER_zz_include, _LOADED_zz_include_env);
--_LOADED_zz_include_env = getfenv(_LOADER_zz_include);
_LOADER_zz_include();
local include = _LOADED_zz_include_env;
print("expecting include.a() to be 2, it is: " .. include.a())
print("expecting a to be nil, it is: " .. tostring(a));

