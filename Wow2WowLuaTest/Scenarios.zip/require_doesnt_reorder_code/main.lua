print(1);

require('printA')

print(2);

require('printB')

print(3);

require('printC')

print(4);
