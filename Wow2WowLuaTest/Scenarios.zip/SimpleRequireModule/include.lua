module('include', package.seeall)
function a()
    return 2;
end
