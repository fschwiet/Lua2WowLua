require('include')
print("expecting include.a() to be 2, it is: " .. include.a())
print("expecting a to be nil, it is: " .. tostring(a));
