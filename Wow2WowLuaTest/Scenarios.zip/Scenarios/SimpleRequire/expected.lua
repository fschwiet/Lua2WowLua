(function()
    a=2
    local b = 2
end)();
print("expecting a to be 2, it is: " .. a);
print("expecting b to be nil, it is: " .. tostring(b));
