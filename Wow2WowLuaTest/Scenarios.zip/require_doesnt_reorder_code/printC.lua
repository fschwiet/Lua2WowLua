module('printC', package.seeall)

print("C");